for REGION in $(aws s3api list-buckets --query "Buckets[].Name" --output text --query 'Regions[].[RegionName]') ; do echo $REGION && aws s3api list-buckets  "Buckets[].Name" --query "Reservations[*].Instances[*].{PublicIP:PublicIpAddress,PrivateIP:PrivateIpAddress,Name:Tags[?Key=='Name']|[0].Value,Type:InstanceType,Status:State.Name,VpcId:VpcId}" --summarize --filters Name=instance-state-name,Values=running --region $REGION; done


aws s3api list-buckets --query "Buckets[].Name" --recursive --human-readable --summarize

#aws s3api list-buckets --query "Buckets[].Name" "Buckets[].size" "Buckets[].count"

for REGION in $(aws s3api list-buckets --query "Buckets[].Name" --output text --query 'Regions[].[RegionName]') ; do echo $REGION && aws s3api list-buckets --query "Buckets[].Name" --filter "Name=status,Values=in-use" --query 'Volumes[*].{VolumeID:VolumeId,Size:Size,Type:VolumeType,AvailabilityZone:AvailabilityZone}' --region $REGION; done

for REGION in $(aws s3api list-buckets --query "Buckets[].Name" --output text --query 'Regions[].[RegionName]') ; do echo $REGION && aws s3api list-buckets --query "Buckets[].Name" --filter "Name=status,"--query {Size:Size,~AvailabilityZone:AvailabilityZone}' --region $REGION; done


aws s3api list-buckets --query "Buckets[].Name"


aws s3api ls list-buckets --query "Buckets[].Name"--recursive --human-readable --summarize --region us-west-1

